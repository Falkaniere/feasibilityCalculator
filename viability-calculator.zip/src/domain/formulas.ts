/**
 * 👉 Esta função foi gerada automaticamente a partir da planilha (quando possível).
 * Auto-convertida da célula P5 (entrada O5→a, F11→b). Revise.
 */
export type Inputs = {{ a: number; b: number }};
export type Result = {{ value: number; label?: string }};

export function computeViability({{ a, b }}: Inputs): Result {{
  if (!isFinite(a) || !isFinite(b)) throw new Error('Valores inválidos');

  // JS expression (a,b) derivada da planilha
  const value = Number(a + b);

  const label = value >= 0 ? 'Viável' : 'Não viável';
  return {{ value, label }};
}}
