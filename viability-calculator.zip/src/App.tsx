import React, { useMemo, useState } from 'react';
import Input from './components/Input';
import { parseLocaleNumber, formatNumber } from './lib/format';
import { computeViability } from './domain/formulas';

export default function App() {
  const [aRaw, setARaw] = useState('');
  const [bRaw, setBRaw] = useState('');
  const [touched, setTouched] = useState(false);

  const a = useMemo(() => parseLocaleNumber(aRaw), [aRaw]);
  const b = useMemo(() => parseLocaleNumber(bRaw), [bRaw]);

  const errors = useMemo(() => {
    const e: Record<string, string | undefined> = {};
    if (touched) {
      if (!isFinite(a)) e.a = 'Informe um número válido';
      if (!isFinite(b)) e.b = 'Informe um número válido';
    }
    return e;
  }, [a, b, touched]);

  const canCalc = isFinite(a) && isFinite(b);
  const result = useMemo(() => (canCalc ? computeViability({ a, b }) : null), [a, b, canCalc]);

  return (
    <div className="container">
      <h1>Calculadora de Viabilidade</h1>
      <p className="subtitle">MVP com 2 campos — fórmula da planilha</p>

      <form
        className="form"
        onSubmit={(ev) => {
          ev.preventDefault();
          setTouched(true);
        }}
      >
        <div className="grid">
          <Input
            label="Campo A"
            placeholder="Ex.: 10.000,00"
            inputMode="decimal"
            value={aRaw}
            onChange={(e) => setARaw(e.target.value)}
            onBlur={() => setTouched(true)}
            error={errors.a}
            aria-invalid={!!errors.a}
          />

          <Input
            label="Campo B"
            placeholder="Ex.: 5.000,00"
            inputMode="decimal"
            value={bRaw}
            onChange={(e) => setBRaw(e.target.value)}
            onBlur={() => setTouched(true)}
            error={errors.b}
            aria-invalid={!!errors.b}
          />
        </div>

        <button type="submit" className="button" disabled={!canCalc}>
          Calcular
        </button>
      </form>

      <section className="result">
        <h2>Resultado</h2>
        {result ? (
          <div className="card">
            <div className="row">
              <span className="k">Valor calculado:</span>
              <span className="v">{formatNumber(result.value, 2)}</span>
            </div>
            {result.label && (
              <div className="row">
                <span className="k">Classificação:</span>
                <span className="v tag">{result.label}</span>
              </div>
            )}
          </div>
        ) : (
          <p className="muted">Preencha os dois campos para ver o resultado.</p>
        )}
      </section>

      <footer className="footer">
        <small>
          Dica: cole números com vírgula (pt-BR). O app aceita ponto ou vírgula e formata o resultado.
        </small>
      </footer>
    </div>
  );
}
