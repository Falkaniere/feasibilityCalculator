/** Conversão segura respeitando pt-BR (vírgula ou ponto). */
export function parseLocaleNumber(raw: string): number {
  if (raw == null) return NaN;
  const s = String(raw).trim().replace(/\./g, '').replace(',', '.');
  // Remove separador de milhar e normaliza decimal
  return Number(s);
}

export function formatNumber(n: number, fractionDigits = 2): string {
  if (!isFinite(n)) return '-';
  return n.toLocaleString('pt-BR', {
    minimumFractionDigits: fractionDigits,
    maximumFractionDigits: fractionDigits,
  });
}

export function formatCurrencyBRL(n: number): string {
  if (!isFinite(n)) return '-';
  return n.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
}
